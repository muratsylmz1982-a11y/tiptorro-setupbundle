_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/

    TSP100LM.DLL/TSP100LMIF.DLL Update Patch

                                                        2021/10/29

_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/

This package fixed a bug that has accumulate the print job in the spooler.


===================
1. Applicable model
===================

  TSP100U   F/W Version 1.1
  TSP100IIU F/W Version 1.0, 1.1, 2.0(*1)

  (*1):The following function restrictions occur in TSP100IIU F/W V2.0.
       - The continuous printing function cannot be used in a virtual
         serial port.


=====================
2. Supported software
=====================

  Driver Software :
    TSP100 V7.6.0 CD


===============
3. Supported OS
===============

  Windows 7                   (32bit/64bit)
  Windows 8.1   Desktop UI    (32bit/64bit)
  Windows 10    Desktop UI    (32bit/64bit)


=============================
4. Install / Uninstall method
=============================

  This package does not include driver software of TSP100 series.
  You have to install TSP100 driver software to use this package.

  Note: Please log in as a "Administrator" authority.

  - Install
    1. Install TSP100 software from CD V7.6.
    2. Unzip this archive package into your PC.
    3. Execute the Command Prompt.
       Note: Please use "Run as administrator".
    4. Execute "Update.bat" from Command Prompt.
       Note: Type "y" and "Enter" when prompted with "Do you want to continue
             this operation?"
             When the "failure" message will appear, please retry to execute
             "Update.bat" until "success".
    5. Close Command Prompt.
    6. Connect the TS100 to a PC to install printer driver.

  - Uninstallation
    1. Unzip this archive package into your PC.
    2. Execute the Command Prompt.
       Note: Please use "Run as administrator".
    3. Execute "Recovery.bat" in a "Recovery" folder from Command Pronpt.
       Note: Type "y" and "Enter" when prompted with "Do you want to continue
             this operation?"
             When the "failure" message will appear, please retry to execute
             "Recovery.bat" until "success".
    4. Close Command Prompt.


====================
5. File constitution
====================

  TSP100_V760_LMUpdatePatch_for_T100U-FW11_T100IIU-FW20.zip
    |
    |  Readme_En.txt                    // book text
    |  Readme_Jp.txt                    // Readme (Japanese)
    |  Update.bat                       // Batch file for installation
    |
    +- x86
    |      TSP100LM.dll                 // 32bit LM   (Bugfix: Print failure)
    |      TSP100LMIF.dll               // 32bit LMIF (Bugfix: Print Failure)
    |
    +- x64
    |      TSP100LM.dll                 // 64bit LM   (Bugfix: Print Failure)
    |      TSP100LMIF.dll               // 64bit LMIF (Bugfix: Print Failure)
    |
    +- Recovery
        |
        |  Recovery.bat                 // Batch file for Uninstallation
        |
        +- x86
        |      TSP100LM.dll             // 32bit LM (V7.6.0 Equal)
        |      TSP100LMIF.dll           // 32bit LM (V7.6.0 Equal)
        |
        +- x64
               TSP100LM.dll             // 64bit LM (V7.6.0 Equal)
               TSP100LMIF.dll           // 64bit LM (V7.6.0 Equal)


============
6. copyright
============

  (C) Star Micronics Co.,Ltd. 2017 - 2021


==================
7. Release History
==================

  2017/03/01
    - Initial release.

  2018/07/06
    - Update LM.
    
  2020/07/09
    - Updated to V7.5.0.

  2021/10/29
    - Updated to V7.6.0.
